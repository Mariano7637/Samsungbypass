# Samsung Account Bypass - Módulo LSPosed

## Descrição

Este módulo LSPosed resolve o erro **"A Samsung Account já existe no gerenciador de contas"** que ocorre no VMOS Cloud ao tentar usar a Galaxy Store. O problema acontece porque a conta Samsung é criada de forma "vazia" no ambiente virtualizado, sem os tokens de autenticação necessários.

## Problema Resolvido

- ✅ Erro "A Samsung Account já existe" ao tentar fazer login
- ✅ Impossibilidade de baixar apps da Galaxy Store
- ✅ Loop de login/logout forçado
- ✅ Conta "fantasma" sem dados reais de autenticação

## Requisitos

- **Android 7.0+** (API 24+)
- **LSPosed Framework** instalado e funcionando
- **VMOS Cloud** ou ambiente similar
- **Root access** (necessário para LSPosed)

## Instalação

### 1. Compilar o Módulo

Se você tem Android Studio:

```bash
cd SamsungAccountBypass
./gradlew assembleRelease
```

O APK será gerado em: `app/build/outputs/apk/release/app-release.apk`

### 2. Instalar o APK

```bash
adb install app/build/outputs/apk/release/app-release.apk
```

Ou transfira o APK para o dispositivo e instale manualmente.

### 3. Ativar no LSPosed

1. Abra o **LSPosed Manager**
2. Vá para **Módulos**
3. Ative o **Samsung Account Bypass**
4. Toque no módulo para configurar o escopo
5. Marque os seguintes aplicativos:
   - ✅ **Galaxy Store** (`com.sec.android.app.samsungapps`)
   - ✅ **Samsung Account** (`com.osp.app.signin`)
6. Reinicie o dispositivo

### 4. Usar a Galaxy Store

Após reiniciar:

1. Abra a **Galaxy Store**
2. Faça login com sua conta Samsung
3. O módulo fará bypass automático das verificações
4. Você poderá baixar apps normalmente!

## Como Funciona

O módulo intercepta e modifica o comportamento de vários métodos críticos:

### Hook 1: `isHaveSA()`
- **Classe:** `com.msc.sa.util.SamsungAccountUtil`
- **Ação:** Retorna `false` em vez de `true`
- **Efeito:** Permite adicionar nova conta mesmo quando já existe uma

### Hook 2: `AccountManager.getAccountsByType()`
- **Classe:** `android.accounts.AccountManager`
- **Ação:** Retorna array vazio para contas Samsung
- **Efeito:** Sistema não detecta conta existente

### Hook 3: `AccountView.setResultWithLog()`
- **Classe:** `com.osp.app.signin.AccountView`
- **Ação:** Converte código de erro (1) em sucesso (-1)
- **Efeito:** Força resultado positivo no login

### Hook 4: `checkReactivationSupported()`
- **Classe:** `com.msc.sa.util.CompatibleAPIUtil`
- **Ação:** Retorna `false`
- **Efeito:** Evita crash por serviços Samsung ausentes no VMOS

## Logs

Para verificar se o módulo está funcionando, use:

```bash
adb logcat | grep "SamsungAccountBypass"
```

Você verá mensagens como:
```
SamsungAccountBypass: Hooking package: com.sec.android.app.samsungapps
SamsungAccountBypass: isHaveSA() bypassed - returning false
SamsungAccountBypass: getAccountsByType bypassed for Samsung Account
```

## Solução de Problemas

### O módulo não aparece no LSPosed
- Verifique se o LSPosed está instalado corretamente
- Reinstale o APK do módulo
- Reinicie o dispositivo

### Ainda recebo o erro de conta duplicada
- Confirme que o módulo está ativado no LSPosed
- Verifique se Galaxy Store e Samsung Account estão no escopo
- Force stop nos dois apps antes de testar
- Limpe dados da Galaxy Store: Configurações > Apps > Galaxy Store > Armazenamento > Limpar dados

### Não consigo baixar apps
- Verifique sua conexão com internet
- Confirme que está logado com uma conta Samsung válida
- Tente remover e adicionar a conta novamente

## Estrutura do Projeto

```
SamsungAccountBypass/
├── app/
│   ├── src/main/
│   │   ├── java/com/samsungaccountbypass/
│   │   │   ├── MainHook.java          # Classe principal com hooks
│   │   │   └── MainActivity.java      # Activity de informações
│   │   ├── res/
│   │   │   └── values/
│   │   │       └── strings.xml
│   │   ├── resources/META-INF/xposed/
│   │   │   ├── java_init.list         # Ponto de entrada
│   │   │   ├── scope.list             # Apps alvo
│   │   │   └── module.prop            # Configurações
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── README.md
```

## Compatibilidade

Testado em:
- ✅ VMOS Cloud
- ✅ Android 10 (API 29)
- ✅ LSPosed v1.9.0+

Pode funcionar em outros ambientes virtualizados com problema similar.

## Avisos

⚠️ **Este módulo modifica o comportamento de aplicativos do sistema Samsung.**

⚠️ **Use por sua conta e risco.**

⚠️ **Não me responsabilizo por problemas causados pelo uso deste módulo.**

## Licença

MIT License - Livre para uso, modificação e distribuição.

## Autor

Desenvolvido por **Manus AI** em 28 de novembro de 2025.

## Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para:
- Reportar bugs
- Sugerir melhorias
- Enviar pull requests

## Suporte

Se tiver problemas:
1. Verifique os logs com `adb logcat`
2. Confirme que seguiu todos os passos de instalação
3. Tente limpar dados da Galaxy Store
4. Reinicie o dispositivo

---

**Nota:** Este módulo foi criado especificamente para resolver um problema técnico no VMOS Cloud e não tem intenção de burlar medidas de segurança legítimas da Samsung.
