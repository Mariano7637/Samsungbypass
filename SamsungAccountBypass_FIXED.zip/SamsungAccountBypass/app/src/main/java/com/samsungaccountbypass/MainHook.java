package com.samsungaccountbypass;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Samsung Account Bypass Module for LSPosed
 * 
 * Este módulo resolve o problema de "conta Samsung já existe" no VMOS Cloud
 * ao fazer bypass das verificações de conta duplicada e forçar autenticação válida.
 * 
 * @author Manus AI
 * @version 1.0
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "SamsungAccountBypass";
    
    // Pacotes alvo
    private static final String GALAXY_STORE_PACKAGE = "com.sec.android.app.samsungapps";
    private static final String SAMSUNG_ACCOUNT_PACKAGE = "com.osp.app.signin";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        
        // Hook apenas nos pacotes relevantes
        if (!lpparam.packageName.equals(GALAXY_STORE_PACKAGE) && 
            !lpparam.packageName.equals(SAMSUNG_ACCOUNT_PACKAGE)) {
            return;
        }

        XposedBridge.log(TAG + ": Hooking package: " + lpparam.packageName);

        // Aplicar hooks
        hookAccountVerification(lpparam);
        hookAccountManager(lpparam);
        hookAccountView(lpparam);
        hookCompatibilityUtils(lpparam);
    }

    /**
     * Hook 1: Bypass da verificação isHaveSA()
     * 
     * Este método verifica se já existe uma conta Samsung.
     * Fazemos retornar false para permitir novo login.
     */
    private void hookAccountVerification(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Tentar múltiplas possíveis classes que contêm isHaveSA()
            String[] possibleClasses = {
                "com.msc.sa.util.SamsungAccountUtil",
                "com.msc.sa.util.SCU",
                "com.samsung.account.util.SamsungAccountUtil"
            };

            for (String className : possibleClasses) {
                try {
                    Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
                    
                    XposedHelpers.findAndHookMethod(clazz, "isHaveSA", new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log(TAG + ": isHaveSA() bypassed - returning false");
                            return false; // Sempre retorna false para permitir adicionar conta
                        }
                    });
                    
                    XposedBridge.log(TAG + ": Successfully hooked isHaveSA() in " + className);
                    break;
                    
                } catch (Throwable t) {
                    // Classe não encontrada, tentar próxima
                    continue;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Error hooking account verification: " + t.getMessage());
        }
    }

    /**
     * Hook 2: Bypass do AccountManager
     * 
     * Permite adicionar conta mesmo quando já existe uma no sistema.
     */
    private void hookAccountManager(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> accountManagerClass = XposedHelpers.findClass(
                "android.accounts.AccountManager", 
                lpparam.classLoader
            );

            // Hook no método getAccountsByType para retornar array vazio
            XposedHelpers.findAndHookMethod(
                accountManagerClass,
                "getAccountsByType",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String accountType = (String) param.args[0];
                        
                        // Se for Samsung Account, retornar array vazio
                        if (accountType != null && accountType.contains("samsung")) {
                            XposedBridge.log(TAG + ": getAccountsByType bypassed for Samsung Account");
                            param.setResult(new Object[0]); // Array vazio
                        }
                    }
                }
            );

            XposedBridge.log(TAG + ": Successfully hooked AccountManager");

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Error hooking AccountManager: " + t.getMessage());
        }
    }

    /**
     * Hook 3: Forçar resultado de sucesso no AccountView
     * 
     * Intercepta o resultado de erro e força sucesso.
     */
    private void hookAccountView(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> accountViewClass = XposedHelpers.findClass(
                "com.osp.app.signin.AccountView",
                lpparam.classLoader
            );

            // Hook no setResultWithLog
            XposedHelpers.findAndHookMethod(
                accountViewClass,
                "setResultWithLog",
                int.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        int resultCode = (int) param.args[0];
                        
                        if (resultCode == 1) { // Código de erro
                            XposedBridge.log(TAG + ": Forcing success result (was error code 1)");
                            param.args[0] = -1; // RESULT_OK
                        }
                    }
                }
            );

            XposedBridge.log(TAG + ": Successfully hooked AccountView.setResultWithLog");

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Error hooking AccountView: " + t.getMessage());
        }
    }

    /**
     * Hook 4: Bypass de verificações de compatibilidade
     * 
     * Evita crashes por serviços Samsung ausentes no VMOS Cloud.
     */
    private void hookCompatibilityUtils(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> compatClass = XposedHelpers.findClass(
                "com.msc.sa.util.CompatibleAPIUtil",
                lpparam.classLoader
            );

            // Hook no checkReactivationSupported
            XposedHelpers.findAndHookMethod(
                compatClass,
                "checkReactivationSupported",
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log(TAG + ": checkReactivationSupported bypassed");
                        return false; // Reativação não suportada no VMOS
                    }
                }
            );

            XposedBridge.log(TAG + ": Successfully hooked CompatibleAPIUtil");

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Error hooking CompatibleAPIUtil: " + t.getMessage());
        }
    }
}
