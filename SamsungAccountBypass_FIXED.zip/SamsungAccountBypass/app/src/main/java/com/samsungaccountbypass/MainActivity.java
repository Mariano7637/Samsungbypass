package com.samsungaccountbypass;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Activity principal do módulo
 * Apenas exibe informações sobre o módulo
 */
public class MainActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        TextView textView = new TextView(this);
        textView.setText(
            "Samsung Account Bypass\n\n" +
            "Este é um módulo LSPosed que resolve o erro de conta Samsung duplicada no VMOS Cloud.\n\n" +
            "Como usar:\n" +
            "1. Ative o módulo no LSPosed Manager\n" +
            "2. Selecione 'Galaxy Store' e 'Samsung Account' no escopo\n" +
            "3. Reinicie o dispositivo\n" +
            "4. Tente fazer login na Galaxy Store novamente\n\n" +
            "O módulo fará bypass automático das verificações de conta duplicada."
        );
        textView.setPadding(50, 50, 50, 50);
        textView.setTextSize(16);
        
        setContentView(textView);
    }
}
